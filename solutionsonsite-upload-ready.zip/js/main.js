(function () {
    'use strict';

    /* ─── Mobile nav toggle ─────────────────────── */
    var navToggle     = document.getElementById('nav-toggle');
    var mobileMenu    = document.getElementById('mobile-menu');
    var hamburgerIcon = document.getElementById('hamburger-icon');
    var closeIcon     = document.getElementById('close-icon');

    function openMenu() {
        mobileMenu.classList.remove('hidden');
        mobileMenu.classList.add('show');
        hamburgerIcon.classList.add('hidden');
        closeIcon.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    function closeMenu() {
        mobileMenu.classList.add('hidden');
        mobileMenu.classList.remove('show');
        hamburgerIcon.classList.remove('hidden');
        closeIcon.classList.add('hidden');
        document.body.style.overflow = '';
    }

    if (navToggle) {
        navToggle.addEventListener('click', function () {
            mobileMenu.classList.contains('hidden') ? openMenu() : closeMenu();
        });
    }

    document.querySelectorAll('.mobile-link').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    document.addEventListener('click', function (e) {
        var navbar = document.getElementById('navbar');
        if (navbar && !navbar.contains(e.target) && mobileMenu && !mobileMenu.classList.contains('hidden')) {
            closeMenu();
        }
    });

    /* ─── Navbar shadow on scroll ───────────────── */
    var navbar = document.getElementById('navbar');
    window.addEventListener('scroll', function () {
        if (navbar) {
            navbar.style.boxShadow = window.scrollY > 10 ? '0 2px 20px rgba(0,0,0,0.25)' : '';
        }
    }, { passive: true });

    /* ─── Contact form ──────────────────────────── */
    var form      = document.getElementById('contact-form');
    var successEl = document.getElementById('form-success');
    var errorEl   = document.getElementById('form-error');
    var submitBtn = document.getElementById('form-submit');

    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (successEl) successEl.classList.add('hidden');
            if (errorEl)   errorEl.classList.add('hidden');

            var name    = document.getElementById('f-name').value.trim();
            var email   = document.getElementById('f-email').value.trim();
            var message = document.getElementById('f-message').value.trim();

            if (!name || !email || !message || message.length < 10) {
                if (errorEl) {
                    errorEl.innerHTML = '<p>Please fill in all required fields (message must be at least 10 characters).</p>';
                    errorEl.classList.remove('hidden');
                }
                return;
            }

            submitBtn.textContent = 'Sending…';
            submitBtn.disabled = true;

            setTimeout(function () {
                submitBtn.innerHTML = 'Send Message <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>';
                submitBtn.disabled = false;
                if (successEl) {
                    successEl.classList.remove('hidden');
                    form.reset();
                    setTimeout(function () { successEl.classList.add('hidden'); }, 7000);
                }
            }, 1400);
        });
    }

    /* ─── Scroll-reveal animation ───────────────── */
    var revealTargets = document.querySelectorAll(
        '.svc-card, .outcome-card, .why-item, .www-card, .step-item, .client-logo-item'
    );

    if ('IntersectionObserver' in window && revealTargets.length) {
        revealTargets.forEach(function (el, i) {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease ' + ((i % 4) * 0.08) + 's, transform 0.5s ease ' + ((i % 4) * 0.08) + 's';
        });

        var obs = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });

        revealTargets.forEach(function (el) { obs.observe(el); });
    }

})();
